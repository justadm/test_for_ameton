<?php
$MESS["WIDGET_WEATHER_TITLE"] = "Виджет погоды";
$MESS["WEATHER_TITLE"] = "Погода в ";
?>